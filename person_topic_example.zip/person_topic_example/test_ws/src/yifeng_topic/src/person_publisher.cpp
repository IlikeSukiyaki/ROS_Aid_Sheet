#include <ros/ros.h>
#include "yifeng_topic/Person.h"

int main(int argc, char **argv)
{
    // ROS node initialization
    ros::init(argc, argv, "person_publisher");

    // Create a NodeHandle
    ros::NodeHandle n;

    // Create a Publisher to publish to /person_info topic with the message type learning_topic::Person
    ros::Publisher person_info_pub = n.advertise<yifeng_topic::Person>("/person_info", 10);

    // Set the loop frequency
    ros::Rate loop_rate(1);

    int count = 0;
    while (ros::ok())
    {
        // Initialize a message of type learning_topic::Person
        yifeng_topic::Person person_msg;
        person_msg.name = "Tom";
        person_msg.age = 18;
        person_msg.sex = yifeng_topic::Person::male;

        // Publish the message
        person_info_pub.publish(person_msg);

        ROS_INFO("Publish Person Info: name:%s age:%d sex:%d",
                 person_msg.name.c_str(), person_msg.age, person_msg.sex);

        // Sleep for the remainder of the loop cycle
        loop_rate.sleep();
    }

    return 0;
}