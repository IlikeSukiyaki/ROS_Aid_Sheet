/**
 * Example ROS subscriber node for /person_info topic, subscribing to messages of type learning_topic::Person
 */

#include <ros/ros.h>
#include "yifeng_topic/Person.h"

// Callback function to process received messages
void personInfoCallback(const yifeng_topic::Person::ConstPtr& msg)
{
    // Print the received message information
    ROS_INFO("Subscribe Person Info: name:%s age:%d sex:%d",
             msg->name.c_str(), msg->age, msg->sex);
}

int main(int argc, char **argv)
{
    // Initialize the ROS node
    ros::init(argc, argv, "person_subscriber");

    // Create a NodeHandle
    ros::NodeHandle n;

    // Create a subscriber to the /person_info topic
    ros::Subscriber person_info_sub = n.subscribe("/person_info", 10, personInfoCallback);

    // Keep the program running and process incoming messages
    ros::spin();

    return 0;
}